import tensorflow as tf
import tensorflow_transform as tft

NUMERIC_FEATURES = [
    'age',
    'daily_steps',
    'heart_rate', 
    'physical_activity_level',
    'quality_of_sleep', 
    'sleep_duration',
    'stress_level'
]

CATEGORICAL_FEATURES = [
    'bmi_category',
    'blood_pressure',
    'gender',
    'occupation'
]

LABEL_KEY = "sleep_disorder"
def transformed_name(key):
    return key + '_xf'

def preprocessing_fn(inputs):
    """Preprocess input features into transformed features."""
    outputs = {}
    
    # Scale numeric features
    for feature_name in NUMERIC_FEATURES:
        outputs[transformed_name(feature_name)] = tft.scale_to_z_score(
            inputs[feature_name])
    
    # Convert categorical features to indices
    for feature_name in CATEGORICAL_FEATURES:
        outputs[transformed_name(feature_name)] = tft.compute_and_apply_vocabulary(
            inputs[feature_name], vocab_filename=feature_name)
    
    # Convert label to int64
    outputs[transformed_name(LABEL_KEY)] = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY], vocab_filename=LABEL_KEY)
    
    return outputs
